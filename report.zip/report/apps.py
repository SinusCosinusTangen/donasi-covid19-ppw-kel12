from django.apps import AppConfig


class ReportConfig(AppConfig):
    name = 'report'
